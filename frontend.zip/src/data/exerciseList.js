// src/data/exerciseList.js
export const exerciseList = [
  { slug: "Basics_01", title: "Basics" },
  { slug: "Mean_01", title: "Mean Deviation" },
  { slug: "Insights_01", title: "Insights" },
  { slug: "SD_01", title: "Standard Deviation" },
  // Add more as needed
];
