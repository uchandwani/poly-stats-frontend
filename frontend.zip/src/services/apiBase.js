// apiBase.js or config.js

export const API_BASE = "/api";
export const AUTH_BASE = `${API_BASE}/auth`;
